<template>
    <div>
        <img src="./logo.png" alt="">
    </div>
</template>

<script>

</script>

<style lang="less" scoped>

</style>