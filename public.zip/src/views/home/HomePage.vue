<template>
    <div>
        <p>我是home的组件</p>
    </div>
</template>

<script>

</script>

<style lang="less" scoped>
</style>